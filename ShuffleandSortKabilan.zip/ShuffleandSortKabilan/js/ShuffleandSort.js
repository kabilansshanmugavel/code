var array = ["1","2","3","4","5","6","7","8","9"]


window.onload = (event) => {
  drawTable(array)
};

var drawTable = (array)=>{
  let  maindiv = document.getElementById('subcontainer');
  maindiv.innerHTML='';
  
array.forEach(element => {
  maindiv.innerHTML+='<div class="subitem'+element+'">'+element+'</li>'
});

}
var sort = ()=>{
  array=array.sort()  
drawTable(array); 

}
var shuffle = () =>{
    var a = array.length, b, c;
  

    while (0 !== a) {
  
 
     c= Math.floor(Math.random() * a);
      a-= 1;
  
     b= array[a];
      array[a] = array[c];
      array[c] = b;
    }
   drawTable(array);
  }
  
